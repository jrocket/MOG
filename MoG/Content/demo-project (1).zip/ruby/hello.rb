# this is the simplest ruby program

puts "Hello world from Cloud9"

# click the 'Run' button at the top to start this application

# === RUNNING RUBY ON RAILS ===
#
# If you want to run Ruby on Rails, please check out the documentation at:
#
#   https://docs.c9.io/running_a_rails_app.html
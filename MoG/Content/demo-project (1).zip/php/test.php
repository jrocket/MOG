<html>
<head></head>
<body>
<pre>
<?php

$bibliotheque = array (1,2,3);
$metatdata = array(1,2,3);
$nbSites = array(1,3);
$nbFichier = array(1,2,3);
$adequation = array(1,3);
$access = array(1,3);



foreach ($bibliotheque as $i)
{
 foreach ($metatdata as $j)
 {
    foreach ($nbSites as $k)
    {
        foreach ($nbFichier as $l)
        {
            foreach ($adequation as $m)
            {
                foreach ($access as $n)
                {
                    echo sprintf("%d;%d;%d;%d;%d;%d\n",$i,$j,$k,$l,$m,$n); 
                }
            }
        }
        
    }
 }
    
}

?>
</pre>
</body>
</html>
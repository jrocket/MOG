<?php
// A simple web site in Cloud9 that runs through Apache
// Press the 'Run' button on the top to start the web server,
// then click the URL that is emitted to the Output tab of the console


$number = 21;
$primes = array();
$primes[0] = 2;
$primes[1] = 3;
$primes[2] = 5;
$primes[3] = 7;
$primes[4] = 11;
$primes[5] = 13;
$primes[6] = 17;
$primes[7] = 19;



do
{
    $flag = true;
    for ( $i=0;$i<8;$i++)
    {
        $flag &= ($number % $primes[$i]==0);
        if (!$flag)
            break;
    }
    if ($number%100==0)
        print $number;
    $number ++;
    if ($number>1000)
        $flag = true;
}
while ($flag == false or false);

print $number-1 ;
?>